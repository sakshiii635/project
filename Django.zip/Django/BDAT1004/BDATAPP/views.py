from django.shortcuts import render 
from django.http import HttpResponse 
from . import models 
# Create your views here.

def home(request):
    query=models.Data.objects.all()
    print (query)
    labels=[]
    data = []

    for item in query:
        labels.append(item.platforms)
        data.append(item.year2020)
       
    # data={
    #     "labels":labels,
    #     "data":data,
    # }
    return render(request,'BDATAPP/home.html',{
        "labels":labels,
        "data":data,
    })
     